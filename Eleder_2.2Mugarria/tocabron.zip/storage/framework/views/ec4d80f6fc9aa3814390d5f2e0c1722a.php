<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => ($appearance ?? 'system') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--Nabigatzailean bilatzen denean:-->
        <meta name="description" content="Pisuak kudeatzeko, informazio zeregin eta gastuen kudeaketadun web aplikazio integratua.">
        <meta name="keywords" content="pisu, pisua, kudeaketa, kudeatu, kudeaketak, zereginak, zeregin, gastu, gastuak, informazio, informazioa, erabiltzaile, elkarbizitza, etxea, pisukideak, alokairua, antolakuntza, zerrendak, ordainketak, egoiliarrak, etxeko lanak, egutegia, egutegi, erosketak, erosketa zerrenda, garbiketa, partekatu, kontuak, dirua, bizikidetza, errenta, jabekideak">
        <meta name="author" content="Pear taldea">
        <!--URL partekatzen denean:-->
        <meta property="og:title" content="<?php echo e(config('app.name')); ?>">
        <meta property="og:description" content="Pisuak kudeatzeko web aplikazio integratua.">
        <meta property="og:image" content="<?php echo e(asset('images/Welcomeirudia.png')); ?>">
        <meta property="og:type" content="website">



        
        <script>
            (function() {
                const appearance = '<?php echo e($appearance ?? "system"); ?>';

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }
            })();
        </script>

        
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
        </style>

        <title inertia><?php echo e(config('app.name', )); ?></title>

        <link rel="icon" type="image/png" href="/Webiconhouse.png">
        <link rel="apple-touch-icon" href="/Webiconhouse.png">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\Users\martz\Desktop\Pear\Eleder_2.2Mugarria\laravel\resources\views/app.blade.php ENDPATH**/ ?>