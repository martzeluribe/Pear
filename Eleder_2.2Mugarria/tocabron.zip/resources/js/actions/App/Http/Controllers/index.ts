import PisoController from './PisoController'
import ZereginController from './ZereginController'
import UserController from './UserController'
import GastuakController from './GastuakController'
import Settings from './Settings'
const Controllers = {
    PisoController: Object.assign(PisoController, PisoController),
ZereginController: Object.assign(ZereginController, ZereginController),
UserController: Object.assign(UserController, UserController),
GastuakController: Object.assign(GastuakController, GastuakController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers