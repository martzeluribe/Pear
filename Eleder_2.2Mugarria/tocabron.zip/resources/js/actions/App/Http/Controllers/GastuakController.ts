import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GastuakController::store
 * @see app/Http/Controllers/GastuakController.php:11
 * @route '/gastuak'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/gastuak',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GastuakController::store
 * @see app/Http/Controllers/GastuakController.php:11
 * @route '/gastuak'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GastuakController::store
 * @see app/Http/Controllers/GastuakController.php:11
 * @route '/gastuak'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GastuakController::store
 * @see app/Http/Controllers/GastuakController.php:11
 * @route '/gastuak'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GastuakController::store
 * @see app/Http/Controllers/GastuakController.php:11
 * @route '/gastuak'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\GastuakController::destroy
 * @see app/Http/Controllers/GastuakController.php:39
 * @route '/gastuak/{gastu}'
 */
export const destroy = (args: { gastu: string | number } | [gastu: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/gastuak/{gastu}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GastuakController::destroy
 * @see app/Http/Controllers/GastuakController.php:39
 * @route '/gastuak/{gastu}'
 */
destroy.url = (args: { gastu: string | number } | [gastu: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gastu: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    gastu: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        gastu: args.gastu,
                }

    return destroy.definition.url
            .replace('{gastu}', parsedArgs.gastu.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GastuakController::destroy
 * @see app/Http/Controllers/GastuakController.php:39
 * @route '/gastuak/{gastu}'
 */
destroy.delete = (args: { gastu: string | number } | [gastu: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\GastuakController::destroy
 * @see app/Http/Controllers/GastuakController.php:39
 * @route '/gastuak/{gastu}'
 */
    const destroyForm = (args: { gastu: string | number } | [gastu: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GastuakController::destroy
 * @see app/Http/Controllers/GastuakController.php:39
 * @route '/gastuak/{gastu}'
 */
        destroyForm.delete = (args: { gastu: string | number } | [gastu: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const GastuakController = { store, destroy }

export default GastuakController