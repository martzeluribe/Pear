import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/pisua/sortu',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PisoController::create
 * @see app/Http/Controllers/PisoController.php:37
 * @route '/pisua/sortu'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\PisoController::store
 * @see app/Http/Controllers/PisoController.php:43
 * @route '/pisua'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pisua',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PisoController::store
 * @see app/Http/Controllers/PisoController.php:43
 * @route '/pisua'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::store
 * @see app/Http/Controllers/PisoController.php:43
 * @route '/pisua'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PisoController::store
 * @see app/Http/Controllers/PisoController.php:43
 * @route '/pisua'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PisoController::store
 * @see app/Http/Controllers/PisoController.php:43
 * @route '/pisua'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pisua',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PisoController::index
 * @see app/Http/Controllers/PisoController.php:16
 * @route '/pisua'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
export const userDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userDashboard.url(options),
    method: 'get',
})

userDashboard.definition = {
    methods: ["get","head"],
    url: '/nirepisuak',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
userDashboard.url = (options?: RouteQueryOptions) => {
    return userDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
userDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userDashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
userDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userDashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
    const userDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: userDashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
        userDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userDashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PisoController::userDashboard
 * @see app/Http/Controllers/PisoController.php:180
 * @route '/nirepisuak'
 */
        userDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userDashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    userDashboard.form = userDashboardForm
/**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
export const show = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pisua/{pisua}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
show.url = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pisua: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pisua: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pisua: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pisua: typeof args.pisua === 'object'
                ? args.pisua.id
                : args.pisua,
                }

    return show.definition.url
            .replace('{pisua}', parsedArgs.pisua.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
show.get = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
show.head = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
    const showForm = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
        showForm.get = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PisoController::show
 * @see app/Http/Controllers/PisoController.php:73
 * @route '/pisua/{pisua}'
 */
        showForm.head = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
export const edit = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/pisua/{pisua}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
edit.url = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pisua: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pisua: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pisua: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pisua: typeof args.pisua === 'object'
                ? args.pisua.id
                : args.pisua,
                }

    return edit.definition.url
            .replace('{pisua}', parsedArgs.pisua.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
edit.get = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
edit.head = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
    const editForm = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
        editForm.get = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PisoController::edit
 * @see app/Http/Controllers/PisoController.php:135
 * @route '/pisua/{pisua}/edit'
 */
        editForm.head = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\PisoController::update
 * @see app/Http/Controllers/PisoController.php:141
 * @route '/pisua/{pisua}'
 */
export const update = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/pisua/{pisua}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PisoController::update
 * @see app/Http/Controllers/PisoController.php:141
 * @route '/pisua/{pisua}'
 */
update.url = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pisua: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pisua: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pisua: args.pisua,
                }

    return update.definition.url
            .replace('{pisua}', parsedArgs.pisua.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::update
 * @see app/Http/Controllers/PisoController.php:141
 * @route '/pisua/{pisua}'
 */
update.put = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PisoController::update
 * @see app/Http/Controllers/PisoController.php:141
 * @route '/pisua/{pisua}'
 */
    const updateForm = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PisoController::update
 * @see app/Http/Controllers/PisoController.php:141
 * @route '/pisua/{pisua}'
 */
        updateForm.put = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\PisoController::destroy
 * @see app/Http/Controllers/PisoController.php:173
 * @route '/pisua/{pisua}'
 */
export const destroy = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pisua/{pisua}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PisoController::destroy
 * @see app/Http/Controllers/PisoController.php:173
 * @route '/pisua/{pisua}'
 */
destroy.url = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pisua: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pisua: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pisua: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pisua: typeof args.pisua === 'object'
                ? args.pisua.id
                : args.pisua,
                }

    return destroy.definition.url
            .replace('{pisua}', parsedArgs.pisua.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::destroy
 * @see app/Http/Controllers/PisoController.php:173
 * @route '/pisua/{pisua}'
 */
destroy.delete = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PisoController::destroy
 * @see app/Http/Controllers/PisoController.php:173
 * @route '/pisua/{pisua}'
 */
    const destroyForm = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PisoController::destroy
 * @see app/Http/Controllers/PisoController.php:173
 * @route '/pisua/{pisua}'
 */
        destroyForm.delete = (args: { pisua: number | { id: number } } | [pisua: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\PisoController::addMember
 * @see app/Http/Controllers/PisoController.php:208
 * @route '/pisua/{pisua}/add-member'
 */
export const addMember = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addMember.url(args, options),
    method: 'post',
})

addMember.definition = {
    methods: ["post"],
    url: '/pisua/{pisua}/add-member',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PisoController::addMember
 * @see app/Http/Controllers/PisoController.php:208
 * @route '/pisua/{pisua}/add-member'
 */
addMember.url = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pisua: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pisua: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pisua: args.pisua,
                }

    return addMember.definition.url
            .replace('{pisua}', parsedArgs.pisua.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::addMember
 * @see app/Http/Controllers/PisoController.php:208
 * @route '/pisua/{pisua}/add-member'
 */
addMember.post = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addMember.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PisoController::addMember
 * @see app/Http/Controllers/PisoController.php:208
 * @route '/pisua/{pisua}/add-member'
 */
    const addMemberForm = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addMember.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PisoController::addMember
 * @see app/Http/Controllers/PisoController.php:208
 * @route '/pisua/{pisua}/add-member'
 */
        addMemberForm.post = (args: { pisua: string | number } | [pisua: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addMember.url(args, options),
            method: 'post',
        })
    
    addMember.form = addMemberForm
/**
* @see \App\Http\Controllers\PisoController::removeMember
 * @see app/Http/Controllers/PisoController.php:228
 * @route '/pisua/{pisua}/member/{user}'
 */
export const removeMember = (args: { pisua: string | number, user: string | number } | [pisua: string | number, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeMember.url(args, options),
    method: 'delete',
})

removeMember.definition = {
    methods: ["delete"],
    url: '/pisua/{pisua}/member/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PisoController::removeMember
 * @see app/Http/Controllers/PisoController.php:228
 * @route '/pisua/{pisua}/member/{user}'
 */
removeMember.url = (args: { pisua: string | number, user: string | number } | [pisua: string | number, user: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    pisua: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pisua: args.pisua,
                                user: args.user,
                }

    return removeMember.definition.url
            .replace('{pisua}', parsedArgs.pisua.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PisoController::removeMember
 * @see app/Http/Controllers/PisoController.php:228
 * @route '/pisua/{pisua}/member/{user}'
 */
removeMember.delete = (args: { pisua: string | number, user: string | number } | [pisua: string | number, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeMember.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PisoController::removeMember
 * @see app/Http/Controllers/PisoController.php:228
 * @route '/pisua/{pisua}/member/{user}'
 */
    const removeMemberForm = (args: { pisua: string | number, user: string | number } | [pisua: string | number, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeMember.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PisoController::removeMember
 * @see app/Http/Controllers/PisoController.php:228
 * @route '/pisua/{pisua}/member/{user}'
 */
        removeMemberForm.delete = (args: { pisua: string | number, user: string | number } | [pisua: string | number, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeMember.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeMember.form = removeMemberForm
const PisoController = { create, store, index, userDashboard, show, edit, update, destroy, addMember, removeMember }

export default PisoController